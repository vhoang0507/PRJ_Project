﻿CREATE DATABASE DuAnPRJ;
GO
USE DuAnPRJ;
GO

-- Bảng Người Dùng
CREATE TABLE Users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) NOT NULL UNIQUE,
	name NVARCHAR(100),
    password NVARCHAR(255) NOT NULL,
    email NVARCHAR(100) NOT NULL UNIQUE,
    location NVARCHAR(100),
    gender NVARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    age INT NOT NULL,
    role NVARCHAR(20) DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
    created_at DATETIME DEFAULT GETDATE()
);


INSERT Users (username, password, name, email, location, gender, age, role) VALUES
('dung','dung','Huynh Dung','huynhdung123@gmail.com','123,456,789','Male',30,'customer');
GO
INSERT Users (username, password, name, email, location, gender, age, role) VALUES
('nam','nam','Nguyen Nam','admin123@gmail.com','123,456,789','Male',100,'admin');
GO
INSERT Users (username, password, name, email, location, gender, age, role) VALUES
('john', 'password123', 'John Doe', 'john@example.com', 'New York, USA', 'Male', 35, 'customer');
GO
INSERT Users (username, password, name, email, location, gender, age, role) VALUES
('jane', 'securepass', 'Jane Smith', 'jane@example.com', 'London, UK', 'Female', 28, 'customer');
GO
INSERT Users (username, password, name, email, location, gender, age, role) VALUES
('alice', 'alicepass', 'Alice Wonderland', 'alice@example.com', 'Sydney, Australia', 'Female', 32, 'customer');
GO


-- Bảng Thám Tử
CREATE TABLE Detectives (
    detective_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    rating FLOAT DEFAULT 0,
    experience_years INT NOT NULL,
    phone_number NVARCHAR(15) NOT NULL UNIQUE,
    email NVARCHAR(200) UNIQUE,
    available BIT DEFAULT 1
);

INSERT INTO Detectives (name, rating, experience_years, phone_number, email, available) VALUES
('Sherlock Holmes', 4.9, 15, '1234567890', 'sherlock@detective.com', 1);
GO
INSERT INTO Detectives (name, rating, experience_years, phone_number, email, available) VALUES
('Hercule Poirot', 4.8, 20, '0987654321', 'poirot@detective.com', 1);
GO
INSERT INTO Detectives (name, rating, experience_years, phone_number, email, available) VALUES
('Nancy Drew', 4.5, 10, '1122334455', 'nancy@detective.com', 1);
GO
INSERT INTO Detectives (name, rating, experience_years, phone_number, email, available) VALUES
('Sam Spade', 4.7, 18, '6677889900', 'sam@detective.com', 1);
GO


-- Bảng Chuyên Môn Thám Tử
CREATE TABLE DetectiveSpecializations (
    specialization_id INT IDENTITY(1,1) PRIMARY KEY,
    detective_id INT,
    specialization NVARCHAR(255) NOT NULL,
    FOREIGN KEY (detective_id) REFERENCES Detectives(detective_id) ON DELETE CASCADE
);



-- Bảng Dịch Vụ
CREATE TABLE Services (
    service_id INT IDENTITY(1,1) PRIMARY KEY,
    service_name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX),
    price float NOT NULL
);

INSERT INTO Services (service_name, description, price) VALUES
('Find missing people', 'Missing person search service in the area.', 5000000);
GO
INSERT INTO Services (service_name, description, price) VALUES
('Look for evidence', 'Collect evidence for civil or criminal cases.', 7000000);
GO
INSERT INTO Services (service_name, description, price) VALUES
('Search for lost vehicle', 'Stolen vehicle tracking service.', 6000000);
GO
INSERT INTO Services (service_name, description, price) VALUES
('Provide corporate information', 'Investigate information about the business before cooperating.', 8000000);
GO


-- Bảng Đặt Thám Tử
CREATE TABLE Bookings (
    booking_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    detective_id INT,
    service_id INT,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
	content NVARCHAR(MAX),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (detective_id) REFERENCES Detectives(detective_id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES Services(service_id) ON DELETE SET NULL
);

INSERT INTO Bookings (user_id, detective_id, service_id, start_date, end_date, content) VALUES
(1, 1, 1, '2024-03-20', '2024-03-30', 'Search for missing persons in urban areas.');
GO
INSERT INTO Bookings (user_id, detective_id, service_id, start_date, end_date, content) VALUES
(2, 2, 2, '2024-04-01', '2024-04-10', 'Collect evidence for civil lawsuit.');
GO
INSERT INTO Bookings (user_id, detective_id, service_id, start_date, end_date, content) VALUES
(3, 3, 3, '2024-04-05', '2024-04-15', 'Stolen Motorcycle Search.');
GO
INSERT INTO Bookings (user_id, detective_id, service_id, start_date, end_date, content) VALUES
(4, 4, 4, '2024-05-01', '2024-05-10', 'Investigate information about competitor businesses.');
GO


-- Bảng Chi Tiết Đặt Thám Tử
CREATE TABLE BookingDetails (
    booking_id INT PRIMARY KEY,
    request_details NVARCHAR(MAX) NOT NULL,
    result NVARCHAR(MAX),
    FOREIGN KEY (booking_id) REFERENCES Bookings(booking_id) ON DELETE CASCADE
);



-- Bảng Đánh Giá & Nhận Xét
CREATE TABLE Reviews (
    review_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    detective_id INT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    feedback NVARCHAR(MAX),
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (detective_id) REFERENCES Detectives(detective_id) ON DELETE CASCADE
);

-- Bảng Bài Viết Blog
CREATE TABLE Blogs (
    blog_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    title NVARCHAR(255) NOT NULL,
    content NVARCHAR(MAX) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE
);

INSERT INTO Blogs (user_id, title, content) VALUES
(1, 'How to search for missing people effectively', 'SWhen a loved one goes missing, acting quickly and strategically is crucial. Start by reporting to authorities, providing essential details like their last known location, recent photo, and medical conditions. Reach out to family, friends, and the community for support, organizing search teams and assigning specific areas. Utilize social media and flyers to spread awareness, and check hospitals, shelters, and public places. Technology like GPS tracking and security cameras can offer valuable leads. If necessary, seek help from private investigators or missing persons organizations. Persistence, collaboration, and open communication greatly improve the chances of a successful outcome.');
GO
INSERT INTO Blogs (user_id, title, content) VALUES
(2, 'Steps to collect legal evidence', 'Collecting legal evidence properly is essential to ensure its credibility and admissibility in court. Start by identifying the type of evidence needed—physical, digital, testimonial, or forensic. Preserve the scene to prevent tampering and document everything with photos, videos, and notes. Store evidence correctly to avoid contamination, and record witness statements while memories are fresh. Verify authenticity through expert analysis and adhere to legal and ethical standards. Proper evidence collection strengthens a case and upholds justice by ensuring accuracy and legality.');
GO
INSERT INTO Blogs (user_id, title, content) VALUES
(3, 'What to do when you lose your car?', 'Losing your car can be stressful, but quick action improves recovery chances. First, retrace your steps and check nearby areas. Use a GPS tracking app if available, and verify if your car was towed due to parking violations. If theft is suspected, report it to the police with all relevant details. Notify your insurance provider and spread the word through social media and community networks. Check security cameras for possible footage. Always stay cautious and take preventive measures like installing a GPS tracker to avoid future incidents.');
GO
INSERT INTO Blogs (user_id, title, content) VALUES
(4, 'How to investigate business information', 'Investigating business information is essential for making informed decisions and minimizing risks. Start by checking official records, such as business registration, financial reports, and licensing details. Analyze the company’s financial health by reviewing revenue trends, debts, and market performance. Research key executives to evaluate leadership credibility and past ventures. Additionally, assess customer feedback, legal compliance, and past lawsuits while studying industry trends and competitor positioning. Verifying business operations, supplier relationships, and partnerships ensures transparency. A structured approach using reliable sources provides accurate insights for sound decision-making.');
GO



-- Bảng Quản Lý Bình Luận Blog (Sửa lỗi multiple cascade paths)
CREATE TABLE Comments (
    comment_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT,
    blog_id INT,
    comment NVARCHAR(MAX) NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES Users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (blog_id) REFERENCES Blogs(blog_id) ON DELETE NO ACTION -- Ngăn lỗi vòng lặp
);

