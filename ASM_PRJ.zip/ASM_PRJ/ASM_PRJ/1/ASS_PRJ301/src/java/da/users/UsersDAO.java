/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.users;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import da.utils.DBUtils;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguye
 */
public class UsersDAO {
    public UsersDTO login(String username, String password) {
        UsersDTO user = null;
        try {
            Connection con = DBUtils.getConnection();
            String sql = " SELECT user_id, username, name, role FROM Users ";
            sql += " WHERE username = ?  AND password = ? ";
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if (rs != null) {
                if (rs.next()) {
                    user = new UsersDTO();
                    user.setUser_id(rs.getInt("user_id"));
                    user.setUsername(rs.getString("username"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                    
                    
                }
            }
            con.close();
            rs.close();
            ps.close();
        } catch (Exception e) {
        }
        return user;
    }

    public UsersDTO login(UsersDTO user, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public UsersDTO login() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public List<UsersDTO> getAllUsers() throws SQLException, ClassNotFoundException {
        List<UsersDTO> list= new ArrayList<>();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            con = DBUtils.getConnection();
            String sql = "SELECT * FROM Users";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("user_id");
                String user = rs.getString("username");
                String name = rs.getString("name");
                String password = rs.getString("password");
                String email = rs.getString("email");
                String location = rs.getString("location");
                String gender = rs.getString("gender");
                int age = rs.getInt("age");
                String role = rs.getString("role");
                Timestamp created_at = rs.getTimestamp("created_at");
                UsersDTO users = new UsersDTO(id, user, name, password, email, location, gender, age, role, created_at);
                list.add(users);
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    
                }
            }
            if (stmt != null) {
                try{
                    stmt.close();
                }catch (SQLException ex){
                    
                }
            }
            if (con != null) {
                try {
                    con.close();
                }catch (SQLException ex) {
                   
                }
            }
        }
        return list;
    }
    
 //-----------------------------------------------------------------------------------------------------------   
    public boolean createUser(String username, String name, String password, String email, String location, String gender, int age, String role, Timestamp created_at) {
        boolean created = false;
        String sql = "INSERT INTO Users (username, name, password, email, location, gender, age, role, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, name);
            ps.setString(3, password);
            ps.setString(4, email);
            ps.setString(5, location);
            ps.setString(6, gender);
            ps.setInt(7, age);
            ps.setString(8, role);
            ps.setTimestamp(9, new Timestamp(System.currentTimeMillis()));

            int rowsAffected = ps.executeUpdate();
            created = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return created;
    }

//-----------------------------------------------------------------------------------------------------------   
    
    public boolean Delete(String id) {
        boolean deleted = false;
        String sql = "DELETE FROM Users WHERE user_id = ?";
        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setInt(1, Integer.parseInt(id));
            int rowsAffected = ps.executeUpdate();
            deleted = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted;
    }
    
//-----------------------------------------------------------------------------------------------------------   

    public List<UsersDTO> getUsersByUserId(int user_id) throws SQLException {
        List<UsersDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            String sql = "SELECT * FROM Users WHERE user_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, user_id);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                int id = rs.getInt("user_id");
                String user = rs.getString("username");
                String name = rs.getString("name");
                String password = rs.getString("password");
                String email = rs.getString("email");
                String location = rs.getString("location");
                String gender = rs.getString("gender");
                int age = rs.getInt("age");
                String role = rs.getString("role");
                Timestamp created_at = rs.getTimestamp("created_at");
                
                list.add(new UsersDTO(id, user, name, password, email, location, gender, age, role, created_at));
            }
                    
            
        } catch (Exception e) {
        } finally {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        }
        
        return list;
    }
    
//-----------------------------------------------------------------------------------------------------------   

    public boolean editUser(UsersDTO user) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean isUpdated = false;

        try {
            conn = DBUtils.getConnection();
            String sql = "UPDATE Users SET username = ?, name = ?, password = ?, email = ?, location = ?, gender = ?, age = ? WHERE user_id = ?";
            ps = conn.prepareStatement(sql);

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getName());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getLocation());
            ps.setString(6, user.getGender());
            ps.setInt(7, user.getAge());
            ps.setInt(8, user.getUser_id()); 

            isUpdated = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        }

        return isUpdated;
    }

//-----------------------------------------------------------------------------------------------------------  

    public boolean emailcheck(String email) {
        String sql = " SELECT COUNT(*) FROM Users WHERE email = ? ";
        try {
            Connection conn = DBUtils.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1)>0;
            }
            
        } catch (Exception e) {
        }
        return false;
        
    }
    
    
}
