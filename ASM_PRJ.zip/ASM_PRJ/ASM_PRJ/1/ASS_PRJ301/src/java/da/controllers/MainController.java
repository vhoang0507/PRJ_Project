/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import da.users.UsersDAO;
import da.users.UsersDTO;


/**
 *
 * @author hd
 */
public class MainController extends HttpServlet {

    private static final String HOME_PAGE = "Home.jsp";
    
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = HOME_PAGE;
        
        try {
            String action = request.getParameter("action");
            if (action == null) {
                url = HOME_PAGE;
            }
//            your code here
//----------------------------------------------------------------------------------------------------------
//ACTION cua USER
            
            else if (action.equals("DICHVU")) {
                url = "CheckLoginController";
            }
            
            else if (action.equals("GO")) {
                url = "GoDichvu";
            }
            
            else if (action.equals("Login")) {
                url = "LoginController";
            }
            
            else if (action.equals("Create Account")) {
                url = "CreateuserofUser.jsp";
            }
            
            else if (action.equals("LOGIN")) {
                url = "CheckLogintrenController";
            }
            
            else if (action.equals("LOGOUT")) {
                url = "LogoutController";
            }
            
            else if (action.equals("BANGGIATHAMKHAO")) {
                url = "ServicesList";
            }
            
            else if (action.equals("GIOITHIEU")) {
                url = "BlogsList";
            }
            
            else if (action.equals("BOOKINGFORUSER")) {
                url = "CKLBookingofuser";
            }
            
            else if (action.equals("Search")) {
                url = "SearchforBooking";
            }
            
            else if (action.equals("EDITUSEROFUSER")) {
                url = "editUser.jsp";
            }
            
            else if (action.equals("EDIT_USER")) {
                url = "Edituserofuser"; 
            }
            
            else if (action.equals("BOOKINGLIST")) {
                url = "BookingListofUser";
            }
                    
            
//-----------------------------------------------------------------------------
//ACTION cua ADMIN   
            
            else if (action.equals("HOMEADMIN")) {
                url = "Homeadmin.jsp";
            }
         //----------------------------------------------------------------  
            // phần giới thiệu của admin
            else if (action.equals("GIOITHIEUADMIN")) {
                url = "ADMINBlogsList";
            }
            
            else if (action.equals("DELETEBLOGADMIN")) {
                url = "ADMINdeleteBlogs";
            }
            
            else if (action.equals("CREATEBLOGADMIN")) {
                url = "ADMINcreateBlogs";
            }
         //----------------------------------------------------------------   
            // phần dịch vụ của admin
            else if (action.equals("DICHVUADMIN")) {
                url = " ";
            }
         //----------------------------------------------------------------  
            // phần bảng giá của admin
            else if (action.equals("BANGGIATHAMKHAOADMIN")) {
                url = "ADMINServicesList";
            }
            
            else if (action.equals("CREATESERVICEADMIN")) {
                url = "ADMINcreateService";
            }
            
            else if (action.equals("DELETESERVICEADMIN")) {
                url = "ADMINdeleteServices";
            }
         //---------------------------------------------------------------- 
            // phần quản lý user của admin
            else if (action.equals("QUANLYUSER")) {
                url = "ADMINUserController";
            }
            
            else if (action.equals("CREATEUSERADMIN")) {
                url = "ADMINcreateUser";
            }
            
            else if (action.equals("DELETEUSERADMIN")) {
                url = "ADMINdeleteUser";
            }
            
         //---------------------------------------------------------------- 
            // phần quản lý thám tử của admin
            else if (action.equals("QUANLYDETECTIVES")) {
                url = "ADMINDetectivesController";
            }
            
            else if (action.equals("CREATEDETECTIVEADMIN")) {
                url = "ADMINcreateDetectives";
            }
            
            else if (action.equals("DELETEDETECTIVEADMIN")) {
                url = "ADMINdeleteDetectives";
            }
         //----------------------------------------------------------------    
            // phần quản lý booking của admin
            else if (action.equals("QUANLYBOOKINGS")) {
                url = "ADMINBookingsController";
            }
            
            else if (action.equals("CREATEBOOKINGADMIN")) {
                url = "ADMINcreateBookings";
            }
            
            else if (action.equals("DELETEBOOKINGADMIN")) {
                url = "ADMINdeleteBookings";
            }
            
           
                    
            
         //----------------------------------------------------------------    
            else if (action.equals("THONGTINLIENHEADMIN")) {
                url = "Homeadmin.jsp";
            }
            
                    


            
                    
                    
//----------------------------------------------------------------------------------------------------------


        } catch (Exception e) {
            log("Error at MainController: " + e.toString());
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
