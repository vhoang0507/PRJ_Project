/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Comments;

import java.sql.Timestamp;

/**
 *
 * @author nguye
 */
public class CommentsDTO {
    private int comment_id;
    private int user_id;
    private int blog_id;
    private String comment;
    private Timestamp created_at;
    private String name;

    public CommentsDTO() {
    }

    public CommentsDTO(int comment_id, int user_id, int blog_id, String comment, Timestamp created_at, String name) {
        this.comment_id = comment_id;
        this.user_id = user_id;
        this.blog_id = blog_id;
        this.comment = comment;
        this.created_at = created_at;
        this.name = name;
    }

    public int getComment_id() {
        return comment_id;
    }

    public void setComment_id(int comment_id) {
        this.comment_id = comment_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getBlog_id() {
        return blog_id;
    }

    public void setBlog_id(int blog_id) {
        this.blog_id = blog_id;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
    
}
