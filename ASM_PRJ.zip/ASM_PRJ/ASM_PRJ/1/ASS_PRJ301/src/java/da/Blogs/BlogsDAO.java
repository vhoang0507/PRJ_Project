/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Blogs;


import da.utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguye
 */
public class BlogsDAO {
    public List<BlogsDTO> getAllBlogs() throws SQLException, ClassNotFoundException {
        List<BlogsDTO> list= new ArrayList<>();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            con = DBUtils.getConnection();
            String sql = "SELECT * FROM Blogs";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("blog_id");
                int userid = rs.getInt("user_id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                Timestamp created_at = rs.getTimestamp("created_at");
                BlogsDTO blogs = new BlogsDTO(id, userid, title, content, created_at);
                list.add(blogs);
            }
            
        } catch (Exception ex) {
            
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    
                }
            }
            if (stmt != null) {
                try{
                    stmt.close();
                }catch (SQLException ex){
                    
                }
            }
            if (con != null) {
                try {
                    con.close();
                }catch (SQLException ex) {
                    
                }
            }
        }
        return list;
    }
//-----------------------------------------------------------------------------------------------------------    
  
    
    public boolean createBlog(int user_id, String title, String content) {
        boolean created = false;
        String sql = "INSERT INTO Blogs (user_id, title, content, created_at) VALUES (?, ?, ?, ?)";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, user_id);
            ps.setString(2, title);
            ps.setString(3, content);
            ps.setTimestamp(4, new Timestamp(System.currentTimeMillis())); 

            int rowsAffected = ps.executeUpdate();
            created = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return created;
    }
//----------------------------------------------------------------------------------------------------------- 
    
    
   
    public boolean Delete(String id) {
        boolean deleted = false;
        String sql = "DELETE FROM Blogs WHERE blog_id = ?";
        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setInt(1, Integer.parseInt(id));
            int rowsAffected = ps.executeUpdate();
            deleted = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted;
    }
    
    
    
}
