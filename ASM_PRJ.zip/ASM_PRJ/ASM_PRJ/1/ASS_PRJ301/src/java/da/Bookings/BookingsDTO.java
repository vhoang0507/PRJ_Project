/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Bookings;

import java.sql.Timestamp;

/**
 *
 * @author nguye
 */
public class BookingsDTO {
    private int booking_id;
    private int user_id;
    private int detective_id;
    private int service_id;
    private Timestamp start_date;
    private Timestamp end_date;
    private String content;
    private String user_name;
    private String detective_name; 
    private String service_name;

    public BookingsDTO() {
    }

    public BookingsDTO(int booking_id, int user_id, int detective_id, int service_id, Timestamp start_date, Timestamp end_date, String content, String user_name,String detective_name, String service_name ) {
        this.booking_id = booking_id;
        this.user_id = user_id;
        this.detective_id = detective_id;
        this.service_id = service_id;
        this.start_date = start_date;
        this.end_date = end_date;
        this.content = content;
        this.user_name = user_name;
        this.detective_name = detective_name;
        this.service_name = service_name;
    }

    public int getBooking_id() {
        return booking_id;
    }

    public void setBooking_id(int booking_id) {
        this.booking_id = booking_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getDetective_id() {
        return detective_id;
    }

    public void setDetective_id(int detective_id) {
        this.detective_id = detective_id;
    }

    public int getService_id() {
        return service_id;
    }

    public void setService_id(int service_id) {
        this.service_id = service_id;
    }

    public Timestamp getStart_date() {
        return start_date;
    }

    public void setStart_date(Timestamp start_date) {
        this.start_date = start_date;
    }

    public Timestamp getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Timestamp end_date) {
        this.end_date = end_date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getDetective_name() {
        return detective_name;
    }

    public void setDetective_name(String detective_name) {
        this.detective_name = detective_name;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }
    
    
    
}


