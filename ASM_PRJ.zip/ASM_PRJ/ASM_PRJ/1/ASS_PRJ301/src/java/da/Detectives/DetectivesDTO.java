/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Detectives;

/**
 *
 * @author nguye
 */
public class DetectivesDTO {
    private int detective_id;
    private String name;
    private float rating;
    private int experience_years;
    private String phone_number;
    private String email;
    private boolean available;

    public DetectivesDTO() {
    }

    public DetectivesDTO(int detective_id, String name, float rating, int experience_years, String phone_number, String email, boolean available) {
        this.detective_id = detective_id;
        this.name = name;
        this.rating = rating;
        this.experience_years = experience_years;
        this.phone_number = phone_number;
        this.email = email;
        this.available = available;
    }

    public int getDetective_id() {
        return detective_id;
    }

    public void setDetective_id(int detective_id) {
        this.detective_id = detective_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public int getExperience_years() {
        return experience_years;
    }

    public void setExperience_years(int experience_years) {
        this.experience_years = experience_years;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    
}


    