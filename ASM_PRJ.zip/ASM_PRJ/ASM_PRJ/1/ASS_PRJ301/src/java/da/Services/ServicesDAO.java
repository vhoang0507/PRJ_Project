/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Services;

import da.utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguye
 */
public class ServicesDAO {
    public List<ServicesDTO> getAllServices() throws SQLException, ClassNotFoundException {
        List<ServicesDTO> list= new ArrayList<>();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            con = DBUtils.getConnection();
            String sql = "SELECT * FROM Services";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("service_id");
                String name = rs.getString("service_name");
                String description = rs.getString("description");
                Float price = rs.getFloat("price");
                ServicesDTO service = new ServicesDTO(id, name, description, price);
                list.add(service);
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                   
                }
            }
            if (stmt != null) {
                try{
                    stmt.close();
                }catch (SQLException ex){
                   
                }
            }
            if (con != null) {
                try {
                    con.close();
                }catch (SQLException ex) {
                   
                }
            }
        }
        return list;
    }
    
 //-----------------------------------------------------------------------------------------------------------    
  
    
    public boolean createService(String service_name, String description, float price) {
        boolean created = false;
        String sql = "INSERT INTO Services (service_name, description, price) VALUES (?, ?, ?)";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, service_name);
            ps.setString(2, description);
            ps.setFloat(3, price);
            

            int rowsAffected = ps.executeUpdate();
            created = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return created;
    }   
    
 //-----------------------------------------------------------------------------------------------------------   
    
    public boolean Delete(String id) {
        boolean deleted = false;
        String sql = "DELETE FROM Services WHERE service_id = ?";
        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setInt(1, Integer.parseInt(id));
            int rowsAffected = ps.executeUpdate();
            deleted = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted;
    }
//-----------------------------------------------------------------------------------------------------------  

    public ServicesDTO getServicesById(String id) throws SQLException, ClassNotFoundException {
        ServicesDTO services = null;
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "SELECT service_id, service_name, description, price FROM Services WHERE service_id = ?";
        try {
            con = DBUtils.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                int service_id = rs.getInt("service_id");
                String service_name = rs.getString("service_name");
                String description = rs.getString("description");
                float price = rs.getFloat("price");
                
                services = new ServicesDTO(service_id, service_name, description, price);
                
            }
        } catch (Exception e) {
            
        }
        return services;
    }
    
}
