/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Services;

import java.text.DecimalFormat;

/**
 *
 * @author nguye
 */
public class ServicesDTO {
    private int service_id;
    private String service_name;
    private String description;
    private float price;

    public ServicesDTO() {
    }

    public ServicesDTO(int service_id, String service_name, String description, float price) {
        this.service_id = service_id;
        this.service_name = service_name;
        this.description = description;
        this.price = price;
    }

    public int getService_id() {
        return service_id;
    }

    public void setService_id(int service_id) {
        this.service_id = service_id;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
    
    
}
