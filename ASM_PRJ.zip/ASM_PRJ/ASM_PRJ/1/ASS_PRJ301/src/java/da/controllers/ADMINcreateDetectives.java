/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.controllers;

import da.Detectives.DetectivesDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author nguye
 */
@WebServlet(name = "ADMINcreateDetectives", urlPatterns = {"/ADMINcreateDetectives"})
public class ADMINcreateDetectives extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String ratingStr = request.getParameter("rating");
        String eyStr = request.getParameter("experience_years");
        String phone_number = request.getParameter("phone_number");
        String email = request.getParameter("email");
        String available = request.getParameter("available");

        int experience_years = 0;
        float rating = 0;

       
        if (eyStr == null || eyStr.trim().isEmpty()) {
            request.getRequestDispatcher("DetectivescreateAdmin.jsp").forward(request, response);
            return;
        }

        
        if (ratingStr == null || ratingStr.trim().isEmpty()) {
            request.getRequestDispatcher("DetectivescreateAdmin.jsp").forward(request, response);
            return;
        }

        try {
            experience_years = Integer.parseInt(eyStr);
            rating = Float.parseFloat(ratingStr);
        } catch (NumberFormatException e) {
            request.getRequestDispatcher("DetectivescreateAdmin.jsp").forward(request, response);
            return;
        }

        DetectivesDAO dao = new DetectivesDAO();
        boolean success = dao.createDetectives(name, rating, experience_years, phone_number, email, true);

        if (success) {
            response.sendRedirect("ADMINDetectivesController");
        } else {
            request.getRequestDispatcher("DetectivescreateAdmin.jsp").forward(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
