/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.users;


import java.sql.Timestamp;



/**
 *
 * @author nguye
 */
public class UsersDTO {
    private int user_id;
    private String username;
    private String name;
    private String password;
    private String email;
    private String location;
    private String gender;
    private int age;
    private String role;
    private Timestamp created_at;
    

    public UsersDTO(int user_id, String username, String name, String password, String email, String location, String gender, int age, String role, Timestamp created_at) {
        this.user_id = user_id;
        this.username = username;
        this.name = name;
        this.password = password;
        this.email = email;
        this.location = location;
        this.gender = gender;
        this.age = age;
        this.role = role;
        this.created_at = created_at;
    }

    public UsersDTO() {
    }
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }
    
    
    
    




    
    
    
}
