/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.controllers;

import da.Comments.CommentsDAO;
import java.io.IOException;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author nguye
 */
@WebServlet(name = "CreatecommentofUser", urlPatterns = {"/CreatecommentofUser"})
public class CreatecommentofUser extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();
        String userIdStr = (String) session.getAttribute("user_id");
        String comment = request.getParameter("comment");

        if (userIdStr == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        if (comment == null || comment.trim().isEmpty()) {
            response.sendRedirect("DichvuList");
            return;
        }

        try {
            int user_id = Integer.parseInt(userIdStr);
            int blog_id = 1; 
            String blogIdStr = request.getParameter("blog_id");
            if (blogIdStr != null && !blogIdStr.isEmpty()) {
                blog_id = Integer.parseInt(blogIdStr);
            }

            CommentsDAO dao = new CommentsDAO();
            boolean success = dao.createComments(user_id, blog_id, comment, new Timestamp(System.currentTimeMillis()));

            if (success) {
                response.sendRedirect("BlogsList");
            } else {
                request.getRequestDispatcher("DichvuList").forward(request, response);
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("DichvuList");
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
