/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Comments;

import da.utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguye
 */
public class CommentsDAO {
    public List<CommentsDTO> getAllComments() throws SQLException, ClassNotFoundException {
        List<CommentsDTO> list= new ArrayList<>();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            con = DBUtils.getConnection();
            String sql = "SELECT c.comment_id, c.user_id, c.blog_id, c.comment, c.created_at, " +
                        "u.name AS user_name " +  
                        "FROM Comments c " +
                        "JOIN Users u ON c.user_id = u.user_id";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                int comment_id = rs.getInt("comment_id");
                int user_id = rs.getInt("user_id");
                int blog_id = rs.getInt("blog_id");
                String comment = rs.getString("comment");
                Timestamp created_at = rs.getTimestamp("created_at");
                String name = rs.getString("user_name");
                CommentsDTO comments = new CommentsDTO(comment_id, user_id, blog_id, comment, created_at, name);
                list.add(comments);
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    
                }
            }
            if (stmt != null) {
                try{
                    stmt.close();
                }catch (SQLException ex){
                    
                }
            }
            if (con != null) {
                try {
                    con.close();
                }catch (SQLException ex) {
                   
                }
            }
        }
        return list;
    }
//-----------------------------------------------------------------------------------------------------------       
    public boolean createComment(int user_id, int blog_id, String comment) throws ClassNotFoundException {
        String sql = "INSERT INTO Comments (user_id, blog_id, comment, created_at) VALUES (?, ?, ?, ?)";
        boolean created = false;

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, user_id);
            ps.setInt(2, blog_id);
            ps.setString(3, comment);
            ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

            created = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return created;
    }

    public boolean createComments(int user_id, int blog_id, String comment, Timestamp timestamp) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }



    
    
}
