/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Bookings;

import da.utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguye
 */
public class BookingsDAO {
    public List<BookingsDTO> getAllBookings() throws SQLException, ClassNotFoundException {
        List<BookingsDTO> list= new ArrayList<>();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            con = DBUtils.getConnection();
            String sql =  "SELECT b.booking_id, b.user_id, b.detective_id, b.service_id, b.start_date, b.end_date, b.content, " +
                            "u.name AS user_name, d.name AS detective_name, s.service_name " +
                            "FROM Bookings b " +
                            "LEFT JOIN Users u ON b.user_id = u.user_id " +  
                            "LEFT JOIN Detectives d ON b.detective_id = d.detective_id " +
                            "LEFT JOIN Services s ON b.service_id = s.service_id";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                int booking_id = rs.getInt("booking_id");
                int user_id = rs.getInt("user_id");
                int detective_id = rs.getInt("detective_id");
                int service_id = rs.getInt("service_id");
                Timestamp start_date = rs.getTimestamp("start_date");
                Timestamp end_date = rs.getTimestamp("end_date");
                String content = rs.getString("content");
                String user_name = rs.getString("user_name");
                String detective_name = rs.getString("detective_name"); 
                String service_name = rs.getString("service_name"); 
                
                BookingsDTO bookings = new BookingsDTO(booking_id, user_id, detective_id, service_id, start_date, end_date, content, user_name, detective_name, service_name);
                list.add(bookings);
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    
                }
            }
            if (stmt != null) {
                try{
                    stmt.close();
                }catch (SQLException ex){
                    
                }
            }
            if (con != null) {
                try {
                    con.close();
                }catch (SQLException ex) {
                    
                }
            }
        }
        return list;
    }
    
//----------------------------------------------------------------------------------------------------------------------------------------------------
    
    public boolean createBookings(int user_id, int detective_id, int service_id, Timestamp start_date, Timestamp end_date, String content ) {
        boolean created = false;
        String sql = "INSERT INTO Bookings (user_id, detective_id, service_id, start_date, end_date, content ) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBUtils.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, user_id);
            ps.setInt(2, detective_id);
            ps.setInt(3, service_id);
            ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
            ps.setString(6, content);

            int rowsAffected = ps.executeUpdate();
            created = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return created;
    }

//-----------------------------------------------------------------------------------------------------------   
    
    public boolean Delete(String id) {
        boolean deleted = false;
        String sql = "DELETE FROM Bookings WHERE booking_id = ?";
        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setInt(1, Integer.parseInt(id));
            int rowsAffected = ps.executeUpdate();
            deleted = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted;
    } 
//-----------------------------------------------------------------------------------------------------------   

    public List<BookingsDTO> getBookingsByUserId(String id) throws SQLException, ClassNotFoundException {
        List<BookingsDTO> list = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

       
        String sql = "SELECT b.booking_id, b.user_id, b.detective_id, b.service_id, b.start_date, b.end_date, b.content, " +
                        "u.name AS user_name, d.name AS detective_name, s.service_name " +
                        "FROM Bookings b " +
                        "LEFT JOIN Users u ON b.user_id = u.user_id " +
                        "LEFT JOIN Detectives d ON b.detective_id = d.detective_id " +
                        "LEFT JOIN Services s ON b.service_id = s.service_id " +
                        "WHERE b.user_id = ?";

        try {
            con = DBUtils.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {
                int booking_id = rs.getInt("booking_id");
                int user_id = rs.getInt("user_id");
                int detective_id = rs.getInt("detective_id");
                int service_id = rs.getInt("service_id");
                Timestamp start_date = rs.getTimestamp("start_date");
                Timestamp end_date = rs.getTimestamp("end_date");
                String content = rs.getString("content");
                String user_name = rs.getString("user_name");
                String detective_name = rs.getString("detective_name"); 
                String service_name = rs.getString("service_name"); 

                
                BookingsDTO bookings = new BookingsDTO(booking_id, user_id, detective_id, service_id, start_date, end_date, content, user_name, detective_name, service_name);
                list.add(bookings);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (con != null) con.close();
        }
        return list;
    
    }    
//-----------------------------------------------------------------------------------------------------------   

    

}
