/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Blogs;


import java.sql.Timestamp;

/**
 *
 * @author nguye
 */
public class BlogsDTO {
    private int blog_id;
    private int user_id;
    private String title;
    private String content;
    private Timestamp created_at;

    public BlogsDTO() {
    }

    public BlogsDTO(int blog_id, int user_id, String title, String content, Timestamp created_at) {
        this.blog_id = blog_id;
        this.user_id = user_id;
        this.title = title;
        this.content = content;
        this.created_at = created_at;
    }

    


    public int getBlog_id() {
        return blog_id;
    }

    public void setBlog_id(int blog_id) {
        this.blog_id = blog_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }
    
    
    
}
