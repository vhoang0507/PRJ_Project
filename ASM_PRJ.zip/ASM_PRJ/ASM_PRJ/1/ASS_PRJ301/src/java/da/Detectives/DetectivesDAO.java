/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package da.Detectives;
import da.utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguye
 */
public class DetectivesDAO {
    public List<DetectivesDTO> getAllDetectives() throws SQLException, ClassNotFoundException {
        List<DetectivesDTO> list= new ArrayList<>();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            con = DBUtils.getConnection();
            String sql = "SELECT * FROM Detectives";
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("detective_id");
                String name = rs.getString("name");
                float rating = rs.getFloat("rating");
                int experience_years = rs.getInt("experience_years");
                String phone_number = rs.getString("phone_number");
                String email = rs.getString("email");
                boolean available = rs.getBoolean("available");
                
                DetectivesDTO detectives = new DetectivesDTO(id, name, rating, experience_years, phone_number, email, available);
                list.add(detectives);
            }
        }catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    
                }
            }
            if (stmt != null) {
                try{
                    stmt.close();
                }catch (SQLException ex){
                    
                }
            }
            if (con != null) {
                try {
                    con.close();
                }catch (SQLException ex) {
                    
                }
            }
        }
        return list;
    }
    
//-----------------------------------------------------------------------------------------------------------    
  
    
    public boolean createDetectives(String name, float rating, int experience_years, String phone_number, String email, boolean available ) {
        boolean created = false;
        String sql = "INSERT INTO Detectives (name, rating, experience_years, phone_number, email, available) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setFloat(2, rating);
            ps.setInt(3, experience_years);
            ps.setString(4, phone_number);
            ps.setString(5, email);
            ps.setBoolean(6, available);
            
            int rowsAffected = ps.executeUpdate();
            created = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return created;
    } 
    
//-----------------------------------------------------------------------------------------------------------        
    public boolean Delete(String id) {
        boolean deleted = false;
        String sql = "DELETE FROM Detectives WHERE detective_id = ?";
        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setInt(1, Integer.parseInt(id));
            int rowsAffected = ps.executeUpdate();
            deleted = (rowsAffected > 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return deleted;
    }
    
    
}
